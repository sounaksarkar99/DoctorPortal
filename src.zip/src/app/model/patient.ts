export class Patient {

  patientId: number;
  patientName: String;
  mobileNo: String;
  email: String;
  type: String;
  bname:String;
  password: String;
  bloodGroup: String;
  gender: String;
  age: number;
  address: String;

}
